$(document).ready(function() {

	$('.pagination').jqPagination({
		link_string	: '/?page={page_number}',
		max_page	: 2,
		page_string : 'Сторінка {current_page} з {max_page}',
		paged		: function(page) {
			$('.log').prepend('<li>Запрошен переход к странице ' + page + '</li>');
		}
	});

});